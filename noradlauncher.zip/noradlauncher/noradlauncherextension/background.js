chrome.runtime.onMessage.addListener((message) => {
    if (message.newTime) {
        // Encode the raw UTC string
        const encodedTime = btoa(message.newTime);

        // Update the declarativeNetRequest rule dynamically with the new time
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1],
            addRules: [
                {
                    id: 1,
                    priority: 1,
                    action: {
                        type: "redirect",
                        redirect: {
                            url: "data:text/plain;base64," + encodedTime // raw text
                        }
                    },
                    condition: {
                        urlFilter: "*://*/timer",
                        resourceTypes: ["xmlhttprequest", "main_frame", "sub_frame"]
                    }
                },
            ]
        });

        console.log("Timer redirect rule updated with new time (raw text):", message.newTime);
    }
});
