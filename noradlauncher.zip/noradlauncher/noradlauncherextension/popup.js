const timeOption = document.getElementById('timeOption');
const customTimeFields = document.getElementById('customTimeFields');
const finishButton = document.getElementById('finishButton');

timeOption.addEventListener('change', () => {
    customTimeFields.style.display = timeOption.value === 'custom' ? 'block' : 'none';
});

finishButton.addEventListener('click', () => {
    let utcTimeStr = '';

    switch (timeOption.value) {
        case 'custom':
            const year = parseInt(document.getElementById('year').value) || 2025;
            const day = parseInt(document.getElementById('day').value) || 1;
            const month = (parseInt(document.getElementById('month').value) || 1) - 1; // zero-based
            const hour = parseInt(document.getElementById('hour').value) || 0;
            const minute = parseInt(document.getElementById('minute').value) || 0;
            const second = parseInt(document.getElementById('second').value) || 0;

            if (month < 0 || month > 11 || day < 1 || day > 31 || hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
                alert("Invalid date/time input!");
                return;
            }

            const date = new Date(year, month, day, hour, minute, second);

            // Convert to UTC string format "MM/DD/YYYY HH:MM:SS"
            const pad = (n) => n.toString().padStart(2, '0');
            utcTimeStr = `${pad(date.getUTCMonth() + 1)}/${pad(date.getUTCDate())}/${date.getUTCFullYear()} ` +
                         `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;

            // Alert user with raw text
            alert(`Timer set to: ${utcTimeStr}`);
            console.log("UTC Time String:", utcTimeStr);
            break;
    }

    // Store the UTC string and send it to background
    chrome.storage.local.set({ selectedTime: utcTimeStr }, () => {
        console.log("Saved UTC time in chrome.storage.local:", utcTimeStr);

        // Send raw text to background
        chrome.runtime.sendMessage({ newTime: utcTimeStr }, (response) => {
            console.log("Response from runtime.sendMessage:", response);
        });

        // Open a new window
        window.open('https://noradsanta.org', '_blank');
    });
});
